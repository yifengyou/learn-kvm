/*
 * Empty file to satisfy #include <linux/math64.h> for older kernels.
 */
