/*
 * Empty file to satisfy #include <linux/asm.h> for older kernels.
 */
