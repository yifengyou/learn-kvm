/*
 * Empty file to satisfy #include <linux/cmpxchg.h> for older kernels.
 */
